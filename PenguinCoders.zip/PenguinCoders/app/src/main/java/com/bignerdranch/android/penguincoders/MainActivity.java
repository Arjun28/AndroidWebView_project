package com.bignerdranch.android.penguincoders;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {

    private WebView webView; //

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CustomWebViewClient client = new CustomWebViewClient(this); //custom client (CustomWebViewClient)
        webView = findViewById(R.id.webView); //default...
        webView.setWebViewClient(client); //set webView client & open in same app | else opens in external browser
        webView.getSettings().setJavaScriptEnabled(true); // enable JS
        //webView.setWebChromeClient(new WebChromeClient()); //use chrome client if needed & enable hardware acceleration andoroidManifest.xml

        //use any url -
        // local host(use "http://192.168.1.5:8000/") or
        // webpage("https://github.com/Arjun28/") or
        // local html file("file:///android_asset/index.html") | In dir - app/src/main/  choose assets. then copy paste .html file into app/src/main/assets
        webView.loadUrl("file:///android_asset/homepage.html");
    }

    //Go Back Button function
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode == KeyEvent.KEYCODE_BACK && this.webView.canGoBack()){
            this.webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

}

//handle link clicks within same webview
class CustomWebViewClient extends WebViewClient{
    private Activity activity;

    public CustomWebViewClient(Activity activity) {
        this.activity = activity;
    }
    //API level < 24
    @Override
    public boolean shouldOverrideUrlLoading(WebView webView, String url){
        return false;
    }
    //API level >=24
    @Override
    public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest request){
        return false;
    }

}


